﻿Colating IME输入法说明：

The Colating IME user manual, Use the txt editor to open the file
"colating-ime-char.schema.yaml" and see it.

===================== 

changelog
colating-cofang-ime-RimeYaml
0.1.12.5：增加了sogou的2021/11最新字库。

0.1.12.7：取消sogou的2021/11最新字库，似乎并不好用？
采用编辑“用户字典管理”-“导出文本码表”/“导入文本码表”(luna_pinyin_export.txt)的方式来取代。




