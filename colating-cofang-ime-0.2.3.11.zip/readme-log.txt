﻿Colating IME输入法说明：

The Colating IME user manual, Use the txt editor to open the file
"colating-ime-char.schema.yaml" and see it.

ChangLog
A. colating-cofang-ime-RimeYaml
0.1.12.4：稍微修改了说明部分。

B. ColatingCofangSans.ttf
0.2.3.11：修改了4个功能字母的位置，2个功能字母的形状。

