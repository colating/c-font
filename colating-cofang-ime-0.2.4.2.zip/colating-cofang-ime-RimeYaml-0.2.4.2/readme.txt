V0.1.0.2

How to use Colating IME

1. Support Rime Input Method Engine, https://github.com/rime/
2. The Colating IME user manual, Use the txt editor to open the file
"colating-ime-char.schema.yaml" and see it.

3. Must install Colating font, Colating Rime yaml file before use the IME.
The Colating font that is in the zip file, The file name such as "colating-cofang-ime-0.2.4.0".
The font file name is "ColatingCofangSans.ttf".

4. Or you can downlaod the  "c-ime-in-os" version to try.